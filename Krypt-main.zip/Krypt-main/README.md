# Krypt - Explore the World of Cryptocurrency

Krypt - A cryptocurrency app. React , Redux-ToolKit and multiple APIs powered by https://rapidapi.com.

Crypto Api and News-BingApi ---> Rapid API's
